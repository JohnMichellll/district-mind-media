function join(e){e.preventDefault();document.getElementById('note').textContent="You're on the list. Friday starts here.";e.target.querySelector('input').value='';return false;}
