# District Mind Media — Phase 1

Static HTML/CSS/JS site. No framework, no paid hosting required.

## Cloudflare Pages
Create a GitHub repo, upload these three files, then Cloudflare → Workers & Pages → Create application → Pages → Import an existing Git repository.
Production branch: `main`
Build command: `exit 0`
Build output directory: `/`

Cloudflare Pages supports static HTML and provides a `pages.dev` subdomain after deployment.
